package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.support.Repositories;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.repository.userRepo;

@RestController
public class UserController {

	@Autowired

	private userRepo repository;

	@PostMapping("/addUser")
	public String saveUser(@RequestBody Employee employee) {
		
		if (employee == null) {
	     
			return "object must not be null";
		}	
		
		repository.save(employee);
		return "Users is addede with id " + employee.getId();

	}
	

	@GetMapping("/findAllUser")
	public List getuser() {
		return (List) repository.findAll();

	}

	@DeleteMapping("/delete/{id}")
	public String deleteBook(@PathVariable int id) {
		
		
		repository.deleteById(id);
		return "User delete with id " + id;

	}

	@PutMapping("/updateUser")
	
	public String updateUser(@RequestBody Employee us) {
	
		if (us == null) 
	        return "object must not be null";

		repository.save(us);

		return "Updated";
	}
	
}
