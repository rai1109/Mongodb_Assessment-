package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.demo.model.Employee;


public interface  userRepo extends  MongoRepository<Employee, Integer> {

}
